<template>
    <header class="header">
      <div class="header-container">
        <!-- 改造Logo为可点击的汉堡按钮 -->
        <div class="logo" @click="toggleNav">
          <i class="bi bi-rocket-takeoff-fill"></i>
        </div>
  
        <!-- 添加导航菜单显示控制类 -->
        <ul class="nav" :class="{ 'mobile-nav-visible': isNavVisible }">
            <li>
              <router-link to="/Home">
                <i class="bi bi-house-door-fill"></i>
                <span>首页</span>
              </router-link>
            </li>
            <li>
              <router-link to="/">
                <i class="bi bi-star-fill"></i>
                <span>推荐</span>
              </router-link>
            </li>
            <li>
              <router-link to="/Vip">
                <i class="bi bi-tag-fill"></i>
                <span>会员中心</span>
              </router-link>
            </li>
            <li>
              <router-link to="/Upload">
                <i class="bi bi-cloud-upload-fill"></i>
                <span>上传视频</span>
              </router-link>
            </li>
          </ul>
  
          <SearchBar class="search-bar" />
  
          <div class="user-section">
            <template v-if="!isLogin">
              <router-link to="/Login" class="login-btn">
                登录/注册
              </router-link>
            </template>
            <template v-else>
              <div class="dropdown">
                <img
                  :src=avatarUrl
                  class="avatar"
                  id="dropdownMenuButton"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                  alt="用户头像"
                />
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <li>
                    <router-link to="/User" class="dropdown-item">
                      <i class="bi bi-person-fill"></i>
                      个人中心
                    </router-link>
                  </li>
                  <li>
                    <button @click="logout" class="dropdown-item">
                      <i class="bi bi-box-arrow-right"></i>
                      退出登录
                    </button>
                  </li>
                </ul>
              </div>
            </template>
          </div>
      </div>
    </header>
  </template>
  
  <script setup>
  import { useStore } from 'vuex';
  import { computed, ref } from 'vue';  // 添加ref用于状态管理
  import SearchBar from './SearchBar.vue';
  
  const store = useStore();
  const isLogin = computed(() => store.state.user.isLogin);
  const logout = async () => { store.dispatch('user/logout'); };
  // 修改默认头像路径
  const avatarUrl = computed(() => store.state.user.avatarUrl || '/default-avatar.png');
  
  // 添加导航显示状态和切换方法
  const isNavVisible = ref(false);
  const toggleNav = () => { isNavVisible.value = !isNavVisible.value; };
  </script>
  
  <style scoped>
  .header {
    background-color: #1a1a1a;
    color: white;
    padding: 0.5rem 1rem;
    position: sticky;
    top: 0;
    z-index: 1000;
  }
  
  .header-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    flex-wrap: wrap;
    gap: 1rem;
  }
  
  .logo {
    cursor: pointer;  /* 添加指针样式提示可点击 */
  }
  
  .logo i {
    font-size: 2rem;
    color: #ffc107;
  }
  
  .nav {
    display: flex;
    gap: 1.5rem;
    list-style: none;
    padding: 0;
    order: 3;
    width: 100%;
    justify-content: center;
    transition: all 0.3s ease;  /* 添加过渡动画 */
  }
  
  /* 移动端隐藏导航，点击Logo后显示 */
  @media (max-width: 768px) {
    .nav {
      display: none;  /* 默认隐藏 */
      flex-direction: column;  /* 移动端垂直排列 */
      align-items: center;
      width: 100%;
      padding: 1rem 0;
    }
    
    .nav.mobile-nav-visible {
      display: flex;  /* 显示状态 */
    }
    
    .nav li {
      width: 100%;
      text-align: center;
    }
    
    .nav a {
      justify-content: center;
      padding: 0.8rem;
    }
  }
  
  .nav a {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: white;
    text-decoration: none;
    padding: 0.5rem;
    transition: all 0.3s ease;
  }
  
  .nav a:hover {
    color: #ffc107;
  }
  
  .nav i {
    font-size: 1.2rem;
  }
  
  .user-section {
    display: flex;
    align-items: center;
    gap: 1rem;
    order: 2;
  }
  
  .search-bar {
    order: 1;
    flex-grow: 1;
    max-width: 400px;
  }
  
  .login-btn {
    padding: 0.5rem 1rem;
    border: 1px solid white;
    border-radius: 4px;
    color: white;
    text-decoration: none;
    transition: all 0.3s ease;
  }
  
  .login-btn:hover {
    background-color: rgba(255, 255, 255, 0.1);
  }
  
  .avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background-color: #555;
    cursor: pointer;
  }
  
  .dropdown-menu {
    background-color: #2a2a2a;
    border: none;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }
  
  .dropdown-item {
    color: white;
    padding: 0.5rem 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.3s ease;
  }
  
  .dropdown-item:hover {
    background-color: rgba(255, 193, 7, 0.1);
  }
  
  @media (max-width: 992px) {
    .header-container {
      flex-direction: column;
      gap: 0.5rem;
    }
    
    .nav {
      order: 2;
      width: auto;
    }
    
    .user-section {
      order: 3;
    }
    
    .search-bar {
      order: 1;
      width: 100%;
      max-width: 100%;
    }
  }
  
  @media (max-width: 768px) {
    .nav span {
      display: none;
    }
    
    .nav i {
      font-size: 1.5rem;
    }
    
    .nav {
      gap: 1rem;
    }
  }
  
  @media (max-width: 576px) {
    .header-container {
      padding: 0.5rem;
    }
    
    .nav {
      gap: 0.5rem;
    }
    
    .nav i {
      font-size: 1.2rem;
    }
  }
</style>