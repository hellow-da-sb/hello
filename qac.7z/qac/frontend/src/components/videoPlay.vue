<template>
    <div class="video-player">
      <video
        ref="videoPlayer"
        :src="videoUrl"
        
        class="video"
        controls
      ></video>
    
    </div>
  </template>

<script setup>
import { ref, defineProps } from "vue";
// 定义props
const props = defineProps({
  videoUrl: {
    type: String,
    required: true,
  },
});


</script>

<style scoped>
.video-player {
    width: 100%;
    max-width: 600px;
    margin: 0 auto;
    position: relative;
  }
  .video {
    width: 100%;
    height: auto;
  }
  .controls {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px;
    background-color: rgba(0, 0, 0, 0.5);
  }
  .control-button,
  .volume-button {
    background-color: #fff;
    border: none;
    padding: 5px 10px;
    cursor: pointer;
  }
  .progress-container {
    display: flex;
    align-items: center;
    flex: 1;
  }
  .progress-bar {
    width: 100%;
    margin: 0 10px;
  }
  .time {
    color: #fff;
  }
  .volume-container {
    display: flex;
    align-items: center;
  }
  .volume-bar {
    width: 100px;
    margin-left: 10px;
  }
  </style>
  