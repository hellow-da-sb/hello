<template>
    <div class="card shadow-sm">
      <img :src="video.coverUrl" class="card-img-top" alt="视频封面">
      <div class="card-body">
        <h5 class="card-title">{{ video.title }}</h5>
        <p class="card-text">{{ video.description }}</p>
        <div class="d-flex justify-content-between align-items-center">
          <small class="text-muted">发布时间: {{ formatDate(video.createdAt) }}</small>
          <div>
            <span class="badge bg-secondary me-2">播放: {{ video.playCount }}</span>
            <span class="badge bg-secondary me-2">点赞: {{ video.likeCount }}</span>
            <span class="badge bg-secondary">评论: {{ video.commentCount }}</span>
          </div>
        </div>
      </div>
    </div>
</template>
<script setup>
import { ref, defineProps } from 'vue'
const { video } = defineProps({video: {type: Object,required: true}})
const videoCover = ref(video.coverUrl||'public/default-avatar.png' )

const formatDate = (dateStr) => {
  return new Date(dateStr).toLocaleDateString()
}
</script>
<style scoped>
.card {
transform: scale(1.05); /* 悬停时放大 */
box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); /* 增强阴影 */
}
.card img:hover {
    transition: all 0.3s ease; /* 定义所有属性的过渡效果 */
  cursor: pointer; /* 鼠标悬停时显示指针样式 */
}
.card:hover {
  transform: translateY(-5px); /* 悬停时向上移动5px */
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15); /* 增强阴影 */
}
</style>