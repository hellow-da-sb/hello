<template>
	<form @submit.prevent class="container mt-5">   
        <div class="p-3"> 
          <div class="list-group mt-3" v-if="uploadProgress > 0">
            <div class="card shadow-sm mb-2" style="max-height: 160px; transition: box-shadow 0.3s ease;" :class="metadata.mimeType.includes('mp4') ? 'border border-1 border-primary' : 'border border-1 border-secondary'" @mouseover="$el.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)'" @mouseleave="$el.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)'">  <!-- 个性化边框颜色+悬停阴影 -->
              <div class="card-body p-2">  <!-- 减少内边距 -->
                <div class="d-flex align-items-center mb-2 gap-2">
                  <i :class="['bi', metadata.mimeType.includes('mp4') ? 'bi-film' : 'bi-file-earmark-play']" style="font-size: 1.2rem;"></i>  <!-- 根据类型显示Bootstrap图标 -->
                  <span class="text-dark fw-semibold" style="flex-grow: 1;">{{ metadata.name }}</span>  <!-- 深色突出文件名 -->
                </div>
                <div class="d-flex justify-content-between align-items-center mb-1">  <!-- 减少行间距 -->
                  <span class="text-muted xsmall" style="font-size: 0.75rem;">大小：{{ (metadata.size / 1024 / 1024).toFixed(2) }} MB</span>
                  <span class="text-muted xsmall" style="font-size: 0.75rem;">时长：{{ (metadata.duration / 60).toFixed(2) }} 分钟</span>
                </div>
                <div class="d-flex justify-content-end align-items-center">
                  <span class="text-nowrap text-muted xsmall" style="font-size: 0.75rem;">格式：{{ metadata.mimeType.replace('video/', '') }}</span>
                </div>
              </div>
            </div>
          </div>
          <div class="d-flex align-items-center gap-2" v-if="uploadProgress > 0 && uploadProgress < 1">
            {{ uploadedSize.toFixed(2)+'/'+videoSize.toFixed(2)+'MB' }}
          </div>
          <!-- 上传进度条 -->
          <div class="progress" style="position: relative;" v-if="uploadProgress > 0 && uploadProgress < 1">   
              <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" role="progressbar" :style="{ width: uploadProgress * 100 + '%'}" :aria-valuenow="uploadProgress * 100" aria-valuemin="0" aria-valuemax="100"></div> 
              <span class="position-absolute top-50 start-50 translate-middle" style="background-color: transparent;">{{ (uploadProgress * 100).toFixed(2) }}%</span> 
          </div>

          <!-- 上传暂停时显示重试按钮 -->
          <div v-if="isUploadPaused" class="mt-2 text-center">
            <button 
              class="btn btn-primary" 
              @click="retryUpload"
              :disabled="isUploading"
            >
              重试上传分片 {{ failedChunkIndex + 1 }}
            </button>
            <div v-if="errorMessage" class="text-danger mt-1">{{ errorMessage }}</div>
          </div>

          <!-- 可点击/拖放的上传区域 -->
          <div class="upload-area" 
               @click="handleClickUpload" 
               @dragenter.prevent="handleDragEnter" 
               @dragover.prevent 
               @dragleave.prevent="handleDragLeave" 
               @drop.prevent="handleDrop" 
               v-if="uploadProgress === 0"
               :aria-dragging="isDragging">
            <p>点击选择视频或拖放视频到此处</p>
            <input type="file" 
                   ref="fileInput" 
                   @change="handleVideoUpload" 
                   accept="video/*" 
                   required 
                   style="display: none;" />
          </div>
    </div>  
</form>
</template>

<script setup>
import { ref, computed,defineEmits} from 'vue'
import { useStore } from 'vuex'

const store = useStore()
// 响应式状态管理
const uploadProgress = ref(0) // 整体上传进度（0-1）
const videoSize = ref(0) // 视频总大小（MB）
const uploadedSize = computed(() => uploadProgress.value * videoSize.value) // 已上传大小（MB）
const isDragging = ref(false) // 拖放状态标记
const isUploadPaused = ref(false) // 上传暂停状态（失败时触发）
const failedChunkIndex = ref(-1) // 失败分片索引（从0开始计数）
const isUploading = ref(false) // 当前是否处于上传中状态
const errorMessage = ref('') // 上传错误提示信息
const videoID = ref('') // 视频唯一标识（由后端返回）
const videoMetadata = ref({})  // 视频元数据（包含时长/尺寸/格式等信息）
const metadata = store.state.videos.videoMetadata // 全局状态中的元数据
const emits = defineEmits(['video']) 

// 触发文件选择框
const handleClickUpload = () => {
  fileInput.value.click()
}
/**
 * 分片文件
 */
const chunk = async (file, size) => {
  const fileChunks = []
  let currentOffset = 0
  while (currentOffset < file.size) {
    fileChunks.push(file.slice(currentOffset, currentOffset + size))
    currentOffset += size
  }
  return fileChunks
}
/**
 * 上传分片策略
 */
async function uploadPolicy(fileChunks, chunksUploaded) {
  isUploading.value = true
  errorMessage.value = ''
  let successCount = 0

  for (let i = 0; i < fileChunks.length; i++) {
    const currentChunk = fileChunks[i]
    let retryTimes = 0

    while (retryTimes < 3) {
      try {
        const response = await chunksUploaded(currentChunk, i)
        if (response.status === 200) {
          // 首分片获取视频ID
          if (i === 0 && response.data.videoID) {
            videoID.value = response.data.videoID
          }
          successCount++
          uploadProgress.value = successCount / fileChunks.length
          console.log(`分片${i+1}上传成功`)
          break
        }
        // 上传失败处理
        retryTimes++
        console.log(`分片${i+1}上传失败，正在重试第${retryTimes}次`)
        if (retryTimes === 3) {
          handleUploadFailure(i)
          return
        }
      } catch (error) {
        console.error(`分片${i+1}网络错误:`, error)
        retryTimes++
        if (retryTimes === 3) {
          handleUploadFailure(i, '网络请求失败，请检查网络')
          return
        }
      }
    }
  }

  // 全部分片上传完成
  handleUploadSuccess()
}

/**
 * 处理上传失败
 */
const handleUploadFailure = (index, msg = '上传失败，请重试') => {
  isUploadPaused.value = true
  failedChunkIndex.value = index
  errorMessage.value = `分片 ${index + 1} ${msg}`
  isUploading.value = false
}

/**
 * 处理上传成功
 */
const handleUploadSuccess = () => {
  uploadProgress.value = 1
  isUploading.value = false
  console.log('视频上传完成！')
  // 清空文件输入框
  if (fileInput.value) {
    fileInput.value.value = ''
  }
}

// 拖放事件处理
const handleDragEnter = () => isDragging.value = true
const handleDragLeave = () => isDragging.value = false

/**
 * 处理文件拖放释放
 */
const handleDrop = (e) => {
  isDragging.value = false
  const [file] = e.dataTransfer.files // 只处理第一个文件
  if (file?.type.startsWith('video/')) {
    const dataTransfer = new DataTransfer()
    dataTransfer.items.add(file)
    fileInput.value.files = dataTransfer.files
    handleVideoUpload({ target: fileInput.value })
  }
}

/**
 * 处理视频上传
 */
const handleVideoUpload = async (e) => {
  const [file] = e.target.files // 只处理第一个文件
  if (!file?.type.startsWith('video/')) return

  emits('video',file)
  // 初始化上传状态
  initUploadState(file)

  // 获取视频元数据
  const metadata = await getVideoMetadata(file)
  videoMetadata.value = metadata
  store.commit('videos/setVideoMetadata', metadata)

  // 分片处理并上传
  const fileChunks = await chunk(file, 1024 * 1024 * 5) // 5MB分片
  const totalChunks = fileChunks.length

  const chunksUploaded = async (currentChunk, index) => {
    const formData = new FormData()
    formData.append('chunk', currentChunk)
    formData.append('chunkIndex', index)
    formData.append('totalChunks', totalChunks)
    formData.append('videoID', videoID.value)
    if (index === 0) {
      formData.append('metadata', JSON.stringify(videoMetadata.value))
    }
    return store.dispatch('videos/uploadVideoChunk', formData)
  }

  await uploadPolicy(fileChunks, chunksUploaded)
}

/**
 * 初始化上传状态
 */
const initUploadState = (file) => {
  uploadProgress.value = 0
  videoSize.value = file.size / (1024 * 1024) // 转换为MB
  isUploadPaused.value = false
  failedChunkIndex.value = -1
  videoID.value = ''
}

/**
 * 获取视频元数据
 */
const getVideoMetadata = async (file) => {
  const videoUrl = URL.createObjectURL(file)
  const videoElement = document.createElement('video')
  videoElement.src = videoUrl

  return new Promise((resolve) => {
    videoElement.onloadedmetadata = () => {
      const metadata = {
        name: file.name,
        size: file.size,
        duration: videoElement.duration,
        width: videoElement.videoWidth,
        height: videoElement.videoHeight,
        mimeType: file.type
      }
      URL.revokeObjectURL(videoUrl)
      resolve(metadata)
    }
  })
}
// 获取文件输入框引用
const fileInput = ref(null)
</script>

<style scoped>
.upload-area {
  border: 2px dashed #ccc;
  border-radius: 8px;
  padding: 20px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s;
  margin: 10px 0;
}

.upload-area:hover {
  border-color: #666;
  background-color: #f8f9fa;
}

.upload-area[aria-dragging="true"] {
  border-color: #2196F3;
  background-color: #e3f2fd;
}

.progress-bar {
  text-align: center;
}
</style>