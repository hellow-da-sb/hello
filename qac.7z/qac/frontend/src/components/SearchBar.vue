<template>
    <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3 search-form" @submit.prevent="handleSearch"> 
        <div class="search-wrapper" ref="searchWrapperRef">  <!-- 添加ref绑定 -->
            <i class="bi bi-search search-icon"></i>
            <input 
                type="search" 
                :placeholder="suggestions[currentSuggestionIndex]" 
                aria-label="Search"
                class="form-control form-control-dark search-input"
                v-bind:class="{ 'expanded': isSearchExpanded }" 
                @focus="handleSearchFocus"
                @blur="handleSearchBlur"
                v-model="searchQuery"
                @keyup.enter="handleSearch"
            >
            <button type="submit" class="search-button">
                <i class="bi bi-arrow-right"></i>
            </button>
            <div v-if="showSuggestions" class="suggestions-box" ref="suggestionsBoxRef">  <!-- 添加ref绑定 -->
                <!-- 限制最多显示5个联想项 -->
                <div 
                    v-for="(suggestion, index) in suggestions.slice(0,9)" 
                    :key="index" 
                    class="suggestion-item"
                    @click="selectSuggestion(suggestion)"
                >
                    {{ suggestion }}
                </div>
            </div>
        </div>
    </form> 
</template>
<script setup>
import { computed, ref, onMounted, onUnmounted, watch } from 'vue';  // 新增watch导入

// 搜索框展开状态
const isSearchExpanded = ref(false); 
// 搜索框内容
const searchQuery = ref('');
// 联想框显示状态
const showSuggestions = ref(false);
// 联想项列表
const suggestions = ref(['联想项 1', '联想项 2', '联想项 3','联想项 4','联想项 5','联想项 6','联想项 7','联想项 8','联想项 9','联想项 10']);
// 当前联想项索引
const currentSuggestionIndex = ref(0);
// 定时器引用
let timer;
// 模板ref绑定DOM元素
const searchWrapperRef = ref(null);
const suggestionsBoxRef = ref(null);

const handleSearchFocus = () => {
    isSearchExpanded.value = true;
    showSuggestions.value = true;
};

const handleSearchBlur = () => {
    setTimeout(() => {
        // 使用模板ref替代document.querySelector
        if (searchQuery.value === '' && (!suggestionsBoxRef.value || !suggestionsBoxRef.value.contains(document.activeElement))) {
            showSuggestions.value = false;
        }
        if (!suggestionsBoxRef.value || !suggestionsBoxRef.value.contains(document.activeElement)) {
            isSearchExpanded.value = false;
        }
    }, 200);  // 延迟200ms避免点击联想项时误关闭
};

const handleClickOutside = (event) => {
    // 使用模板ref判断点击范围
    if (searchWrapperRef.value && !searchWrapperRef.value.contains(event.target) && 
        (!suggestionsBoxRef.value || !suggestionsBoxRef.value.contains(event.target))) {
        showSuggestions.value = false;
    }
};

const selectSuggestion = (suggestion) => {
    searchQuery.value = suggestion;
    showSuggestions.value = false;
    currentSuggestionIndex.value = 0;  // 选择后重置索引
};

const switchSuggestion = () => {
    currentSuggestionIndex.value = (currentSuggestionIndex.value + 1) % suggestions.value.length;
};

// 输入内容时暂停联想项切换，清空时恢复
watch(searchQuery, (newVal) => {
    if (newVal) {
        clearInterval(timer);
        timer = null;
    } else {
        if (!timer) {
            timer = setInterval(switchSuggestion, 10000);
        }
    }
});

const handleSearch = () => {
    if (searchQuery.value === '') {
        searchQuery.value = suggestions.value[currentSuggestionIndex.value];
    }
    showSuggestions.value = false; // 触发搜索时关闭联想框
    isSearchExpanded.value = false; // 新增：触发搜索时关闭搜索栏展开状态
    console.log('Searching for:', searchQuery.value);
};

onMounted(() => {
    document.addEventListener('click', handleClickOutside);
    timer = setInterval(switchSuggestion, 10000);
});

onUnmounted(() => {
    document.removeEventListener('click', handleClickOutside);
    clearInterval(timer);  // 确保清除定时器
});
</script>
<style scoped>


/* 搜索框过渡效果 */
.search-input {
    transition: width 0.3s ease;
    width: 250px; /* 增大默认宽度，可根据需要调整 */
}

.search-input.expanded {
    width: 300px; /* 可根据需要调整展开后的宽度 */
}

/* 新增搜索框样式 */
.search-form {
    display: flex;
    justify-content: center; /* 让搜索框居中 */
}

.search-wrapper {
    position: relative;
}

.search-icon {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: white;
}

.search-input {
    padding-left: 30px; /* 为图标留出空间 */
}

/* 调整搜索图标颜色 */
.search-icon {
    color: #ccc; /* 调整为与背景区分的颜色 */
}

/* 美化搜索按钮 */
.search-button {
    background-color: #6c757d; /* 调整背景颜色 */
    border: 1px solid #6c757d; /* 添加边框 */
    color: white;
    padding: 0.375rem 1rem; /* 调整内边距 */
    border-radius: 0 0.25rem 0.25rem 0;
    margin-left: -1px;
    transition: all 0.3s ease; /* 添加过渡效果 */
    display: flex;
    align-items: center;
    justify-content: center;
}

.search-button:hover {
    background-color: #5a6268; /* 悬停时的背景颜色 */
    border-color: #545b62; /* 悬停时的边框颜色 */
}

/* 当搜索框展开时，调整按钮样式 */
.search-input.expanded + .search-button {
    /* 可以根据需要添加展开时的特殊样式 */
    background-color: #007bff; /* 例如，蓝色背景 */
}

/* 调整搜索框样式以适应按钮 */
.search-wrapper {
    display: flex;
    align-items: center;
}

.search-input {
    border-radius: 0.25rem 0 0 0.25rem;
    flex-grow: 1;
}

/* 添加联想框样式 */
.suggestions-box {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background-color: white;
    border-top: none;
    border-radius: 0 0 0.25rem 0.25rem;
    max-height: 250px;
    overflow-y: auto;
    z-index: 1000;
}

/* 优化输入框文字颜色 */
.search-input {
    transition: width 0.3s ease;
    width: 200px;
    color: #2c3e50; /* 深灰主色，比默认更鲜艳 */
    padding-left: 30px;
}

/* 优化placeholder颜色 */
.search-input::placeholder {
    color: #666; /* 比默认浅灰更明显 */
    opacity: 1; /* 解决部分浏览器透明度问题 */
}
.search-input::-webkit-input-placeholder { color: #666; }
.search-input::-moz-placeholder { color: #666; }
.search-input:-ms-input-placeholder { color: #666; }

/* 优化联想项文字颜色 */
/* 新增联想项分割线样式 */
.suggestion-item {
    padding: 0.5rem 1rem;
    cursor: pointer;
    background-color: #faeeee;
    color: #304a64;
    border-top: 1px solid #fbb3b34c;
    margin: 0.5px;
    border-radius: 0.5rem;  /* 添加圆角，与联想框底部圆角保持一致 */
}

.suggestion-item:last-child {
    border-bottom: none; /* 最后一项取消底部边框 */
}

.suggestion-item:hover {
    background-color: #f0f0f0;
    color: #007bff;
}
</style>