<template>
    <div class="card  custom-card " style="min-width: 400px;">
        <div class="card-body custom-card-body">
          <h2 class="text-center mb-4">{{ isRegistration ? '登录' : '注册' }}</h2>
          <form @submit.prevent>
            <div v-if="!isRegistration" class="mb-3">
              <label for="regUsername" class="form-label">用户名:</label>
              <input type="text" id="regUsername" v-model="regUsername" required class="form-control" autocomplete="username">
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">邮箱:</label>
              <input type="email" id="email" v-model="email" required class="form-control" autocomplete="email">
            </div>
             <div class="mb-3" v-if="!isRegistration">
               <label for="password" class="form-label">手机号:</label>
                <input type="text" id="phone" v-model="phone" required class="form-control" autocomplete="phone"></input>
             </div>
            <div class="mb-3">
              <label for="password" class="form-label">密码:</label>
              <input type="password" id="password" v-model="password" required class="form-control" autocomplete="current-password">
            </div>
            
            <button type="submit" :disabled="isSubmitting" @click="handleSubmit" class="btn btn-primary w-100">
              <span class="spinner-border spinner-border-sm" v-if="isSubmitting"></span>
              {{ isSubmitting ? '提交中...' : (isRegistration ? '登录' : '注册') }}
            </button>
          </form> 
          <div class="mt-3 d-flex justify-content-center"> 
            <div class="btn-group">
              <button :class="{ active: isRegistration }" @click="switchToLogin" class="btn btn-outline-primary">登录</button>
              <button :class="{ active: !isRegistration }" @click="switchToRegister" class="btn btn-outline-primary">注册</button>
            </div>
          </div>
        </div>
        <!-- 登录/注册成功提示 -->
        <div v-if="successMessage" class="alert alert-success mt-3 text-center">{{ successMessage }}</div>
        <!-- 登录/注册错误提示 -->
        <div v-if="errorMessage" class="alert alert-danger mt-3 text-center">{{ errorMessage }}</div>
      </div>
</template>
<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';
import CryptoJS from 'crypto-js';
import { computed } from 'vue';
const router = useRouter();
const store = useStore();
// 切换登录/注册状态
const isRegistration = ref(true);
// 登录/注册响应式数据
const email = ref('');
const password = ref('');
const hashedPassword = computed(() => {
  try {
    return CryptoJS.SHA256(password.value).toString();
  } catch (error) {
    console.error('密码哈希处理出错:', error);
    return '';
  }
});

const regUsername = ref('');
const phone = ref('');
// 提示信息
const successMessage = ref('');
const errorMessage = ref('');
// 提交状态
const isSubmitting = ref(false);
// 切换到登录
const switchToLogin = () => {isRegistration.value = true;};
// 切换到注册
const switchToRegister = () => {isRegistration.value = false;};
// 提交方法
const handleSubmit = () => {
  isRegistration.value ? handleLogin() : handleRegister();
};
//  提示信息
const showMessage = (message, text, isError = false) => {
    message.value = text;
    if (isError) {
        errorMessage.value = text;
        successMessage.value = '';
        setTimeout(() => { errorMessage.value = ''; }, 3000);
    } else {
        successMessage.value = text;
        errorMessage.value = '';
        setTimeout(() => { successMessage.value = ''; }, 3000); // 新增成功提示自动关闭
    }
}
// 登录方法
const handleLogin = async () => {
    if (!email.value || !hashedPassword.value) {    
        showMessage(errorMessage, '请填写邮箱和密码', true); 
        return;
    }
    try {
        const request = await store.dispatch('user/login', { email: email.value, password: hashedPassword.value }); 
        isSubmitting.value = false; //  提交完成后重置状态
        console.log('登录请求结果:', request);
        if (request && request.status === 200) {
            showMessage(successMessage, '登录成功', false);
            router.push('/');
        } 
    } catch (error) {
        console.error('登录请求出错:', error);
        let errorMsg = '登录失败，请稍后重试！';
        if (error.response) {
            // 服务器响应了，但状态码不是 2xx
            const { status, data } = error.response;
            switch (status) {
                case 400:
                    errorMsg = '参数格式错误，请检查邮箱和密码！';
                    break;
                case 401:
                    errorMsg = '身份验证失败，请检查账号和密码！';
                    break;
                case 500:
                    errorMsg = '服务器内部错误，请稍后重试！';
                    break;
                default:
                    errorMsg = data.message || '服务器错误，请稍后重试！';
            }
        } else if (error.request) {
            // 请求已发送，但没有收到响应，通常是网络问题
            errorMsg = '网络连接失败，请检查您的网络！';
        } else {
            // 其他错误，可能是请求配置问题
            errorMsg = '发生未知错误，请稍后重试！';
        }
        showMessage(errorMessage, errorMsg, true);
        isSubmitting.value = false;
    }
};

// 注册方法
const handleRegister = async () => {
    if (isSubmitting.value) return;
    // 新增输入验证
    if (!regUsername.value || !email.value || !phone.value || !hashedPassword.value) {
        showMessage(errorMessage, '请填写用户名、邮箱、手机号和密码', true);
        return;
    }
    isSubmitting.value = true;
    try {
        const userData = {
            username: regUsername.value,
            email: email.value,
            phone: phone.value,
            password: hashedPassword.value
        };
        const request = await store.dispatch('user/register', userData); 
        if (request && request.status === 200) {
            showMessage(successMessage, '注册成功！即将跳转登录', false);
            setTimeout(() => { router.push('/'); }, 2000); // 注册成功后跳转登录页
        }
    } catch (error) {
        console.error('注册失败:', error);
        let errorMsg = '注册失败，请检查您的信息！';
        if (error.response) {
            const { status, data } = error.response;
            switch (status) {
                case 400:
                    errorMsg = '参数格式错误（如邮箱/手机号不正确）！';
                    break;
                case 409:
                    errorMsg = '该邮箱已注册，请直接登录！';
                    break;
                case 500:
                    errorMsg = '服务器内部错误，请稍后重试！';
                    break;
                default:
                    errorMsg = data.message || '服务器错误，请稍后重试！';
            }
        } else if (error.request) {
            errorMsg = '网络连接失败，请检查您的网络！';
        } else {
            errorMsg = '发生未知错误，请稍后重试！';
        }
        showMessage(errorMessage, errorMsg, true);
    } finally {
        isSubmitting.value = false;
    }
};
</script>

<style scoped>
.custom-card {
  min-height: 300px; /* 设置卡片最小高度，确保切换时不改变大小 */
  max-width: 500px; /* 可选：设置最大宽度 */;
}

.custom-card-body {
  padding: 2rem; /* 增加内边距 */
}

.active {
  background-color: #0d6efd;
  color: white;
}
</style>