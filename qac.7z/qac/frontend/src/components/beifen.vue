<template> 
  <div class="container mt-5">
    <h2 class="mb-4">视频上传表单</h2>
    <form @submit.prevent>
      <div class="mb-3">
        <label for="title" class="form-label">标题</label>
        <input type="text" class="form-control" id="title" v-model="videoData.title" required>
      </div>
      <div class="mb-3">
        <label for="tags" class="form-label">标签</label>
        <div class="tag-container">
          <span class="tags" v-for="tag in videoData.tags" :key="tag">{{ tag }}</span>
          <input value="新标签" class="btn btn-primary">
        </div>
      </div>
      <div class="mb-3">
        <label for="description" class="form-label">视频简介</label>
        <textarea class="form-control" id="description" v-model="videoData.description" rows="4"></textarea>
      </div>
      <div class="mb-3">
        <label for="video" class="form-label">上传视频</label>
        <div class="d-flex align-items-center">
          <input type="file" class="form-control" id="video" @change="handleVideoUpload" accept="video/*" required style="flex: 1;">
          <!-- 视频预览 -->
          <video v-if="videoUrl" :src="videoUrl" controls class="mt-2" style="max-width: 50%; margin-left: 1rem;"></video>
        </div>
        <!-- 上传进度条 -->
        <div class="progress mt-2" v-if="uploadProgress > 0">
          <div class="progress-bar" :style="{ width: uploadProgress + '%' }" :aria-valuenow="uploadProgress" aria-valuemin="0" aria-valuemax="100">{{ uploadProgress }}%</div>
        </div>
      </div>
      <div class="mb-3">
        <label for="thumbnail" class="form-label">上传封面</label>
        <input type="file" class="form-control" id="thumbnail" @change="handleThumbnailUpload" accept="image/*" required>
        <!-- 封面预览 -->
        <img v-if="thumbnailUrl" :src="thumbnailUrl" alt="封面预览" class="mt-2" style="max-width: 200px;">
        <button v-if="videoUrl" @click="captureThumbnail" class="btn btn-secondary mt-2">截取封面</button>
      </div>
      <button type="submit" class="btn btn-primary" @click="submitForm">提交</button>
    </form>
  </div>
</template>

<script setup>
import { ref, reactive, watch } from 'vue'

const videoData = reactive({
  tags: ['标签1','标签2'],
  title: '',
  description: '',
  video: null,
  thumbnail: null
})
const videoUrl = ref('')
const thumbnailUrl = ref('')
const uploadProgress = ref(0)

//  上传视频的处理函数
const handleVideoUpload = (event) => {
  const file = event.target.files[0]
  if (file) {
    videoData.video = file
    videoUrl.value = URL.createObjectURL(file)
  }
}

//  上传封面的处理函数
const handleThumbnailUpload = (event) => {
  const file = event.target.files[0]
  if (file) {
    // 释放之前的 URL 对象，避免内存泄漏
    if (videoData.thumbnail) {
      URL.revokeObjectURL(thumbnailUrl.value)
    }
    videoData.thumbnail = file
    thumbnailUrl.value = URL.createObjectURL(file)
  }
}

// 截取封面
const captureThumbnail = () => {
  const video = document.querySelector('video')
  if (video) {
    const canvas = document.createElement('canvas')
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    const ctx = canvas.getContext('2d')
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
    // 释放之前的 URL 对象，避免内存泄漏
    if (videoData.thumbnail) {
      URL.revokeObjectURL(thumbnailUrl.value)
    }
    canvas.toBlob((blob) => {
      videoData.thumbnail = blob
      thumbnailUrl.value = URL.createObjectURL(blob)
    }, 'image/jpeg', 0.95)
  }
}

const submitForm = () => {
  // // 模拟上传进度
  // const xhr = new XMLHttpRequest()
  // xhr.upload.addEventListener('progress', (event) => {
  //   if (event.lengthComputable) {
  //     uploadProgress.value = Math.round((event.loaded / event.total) * 100)
  //   }
  // })
  // xhr.addEventListener('load', () => {
  //   uploadProgress.value = 100
  //   console.log('上传完成')
  // })
  // xhr.open('POST', 'your_upload_url', true)
  const formData = new FormData()
  formData.append('video', videoData.video)
  formData.append('thumbnail', videoData.thumbnail)
  formData.append('title', videoData.title)
  formData.append('description', videoData.description)
  formData.append('tags', videoData.tags)
  // xhr.send(formData)
}
</script>

<style scoped>
.progress {
  height: 20px;
}
.progress-bar {
  transition: width 0.3s ease;
}
</style>

