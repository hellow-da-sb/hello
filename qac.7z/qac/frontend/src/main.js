import { createApp } from 'vue'
import './style.css'
import Router from './router'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'
import 'bootstrap-icons/font/bootstrap-icons.css' 
import store from './store'
import App from './App.vue'

const app = createApp(App)
app.use(Router)
app.use(store)
app.mount('#app')
