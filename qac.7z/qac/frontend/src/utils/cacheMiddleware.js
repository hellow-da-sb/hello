const cache = new Map();
const MAX_CACHE_SIZE = 10; // 最大缓存条目数

const fetchVideoData = (apiClient) => {
  const originalRequest = apiClient.request;

  apiClient.request = async (config) => {
    const useCache = config.useCache || false;
    const cacheKey = config.url;

    if (useCache) {
      if (cache.has(cacheKey)) {
        const cachedResponse = cache.get(cacheKey);
        const cacheAge = Date.now() - cachedResponse.timestamp;

        if (cacheAge > 10 * 60 * 1000) {
          console.log(`Cache expired for ${cacheKey}`);
          cache.delete(cacheKey);
        } else {
          console.log(`Cache hit for ${cacheKey}`);
          return cachedResponse.response;
        }
      }

      // 缓存中没有数据或缓存已失效，发起请求并缓存结果
      const response = await originalRequest(config);
      cache.set(cacheKey, { response, timestamp: Date.now() });

      // 如果缓存超出限制，删除最早缓存的条目
      if (cache.size > MAX_CACHE_SIZE) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
      }

      return response;
    } else {
      return originalRequest(config);
    }
  };

  return apiClient;
};

export default fetchVideoData;
