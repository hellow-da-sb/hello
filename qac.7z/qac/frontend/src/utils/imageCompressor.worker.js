self.onmessage = function(event) {
  const file = event.data;
  

  if (!file.type.match('image.*')) {
    self.postMessage({ error: '不支持的文件类型' });
    return;
  }

  const compressImage = (file) => {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      
      createImageBitmap(file)
        .then((bitmap) => {
          URL.revokeObjectURL(url);
          
          // 替换为 OffscreenCanvas（修改核心）
          const maxWidth = 1920;
          const maxHeight = 1080;
          let width = bitmap.width;
          let height = bitmap.height;
          const widthRatio = maxWidth / width;
          const heightRatio = maxHeight / height;
          const ratio = Math.min(widthRatio, heightRatio, 1);
          width = Math.floor(width * ratio);
          height = Math.floor(height * ratio);
          
          // 使用 OffscreenCanvas 替代 document.createElement('canvas')
          const canvas = new OffscreenCanvas(width, height);
          const ctx = canvas.getContext('2d');

          ctx.drawImage(bitmap, 0, 0, width, height);

          // 转换为 JPEG 格式（OffscreenCanvas 支持 toBlob）
          canvas.convertToBlob({
            type: 'image/jpeg',
            quality: 0.8
          })
          .then((blob) => {
            const compressedFile = new File([blob], file.name, {
              type: 'image/jpeg',
              lastModified: Date.now()
            });
            resolve(compressedFile);
          })
          .catch(() => reject(new Error('压缩失败')));
        })
        .catch((error) => {
          URL.revokeObjectURL(url);
          reject(new Error('图片加载失败: ' + error.message));
        });
    });
  };
  compressImage(file)
    .then((compressedFile) => {
      self.postMessage(compressedFile);
    })
    .catch((error) => {
      self.postMessage({ 
        error: error.message,
        stack: error.stack
      });
    });
};
