<script setup>
import Header from './components/Header.vue';
</script>

<template >
    <Header />
    <RouterView ></RouterView>
</template>

<style scoped>

</style>
