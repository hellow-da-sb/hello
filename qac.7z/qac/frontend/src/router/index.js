import { createRouter, createWebHashHistory } from 'vue-router';
import store from '../store'; // 引入Vuex存储


const routes = [
  { path: '/', redirect: '/Home' },
  { path: '/Home', name: 'Home', component: () => import('../views/Home.vue'), meta: { permission: 'public' } }, 
  { path: '/User', name: 'User', component: () => import('../views/User.vue'), meta: { permission: 'public' } },
  { path: '/Video/:id', name: 'VideoDetail', component: () => import('../views/VideoDetail.vue'), meta: { permission: 'public' } }, 
  {path:'/Vip', name:'Vip', component:()=>import('../views/Vip.vue'), meta: { permission: 'public' } }, // 仅VIP用户可访问
  { path:'/403', name: '403', component: () => import('../views/err/403.vue'), meta: { permission: 'public' } }, // 无权限页面，所有用户均可访问
  { path:'/404', name: '404', component: () => import('../views/err/404.vue'), meta: { permission: 'public' } }, // 404页面，所有用户均可访问
  { path:'/500',  name:'500', component: () => import('../views/err/500.vue'), meta: { permission: 'public' } }, // 500页面，所有用户均可访问
  { path:'/Login', name: 'Login', component: () => import('../views/Login.vue'), meta: { permission: 'public' } },
  { path:'/Upload', name: 'Upload', component: () => import('../views/Upload.vue'), meta: { permission: 'public' } },
   
];

const router = createRouter({
  history: createWebHashHistory(),
  routes
});

// 添加全局前置守卫进行权限校验
router.beforeEach((to, from, next) => {
  const isLogin = store.state.user.isLogin; // 获取登录状态（需确保store中已正确维护该状态）
  const userRole = store.state.user.role; // 获取用户角色（需登录后从后端获取并存储）
  const data = from.params.data || from.query.data;
  
  if(data) {to.params.sharedData = data;}
  // 公共路由直接放行
  if (to.meta.permission === 'public') {
    return next();
  }

  // 未登录用户重定向到登录页
  if (!isLogin) {
    return next({ name: 'Login' });
  }
  // 权限校验逻辑
  switch (to.meta.permission) {
    case 'user': // 所有已登录用户都有user权限
      next();
      break;
    case 'vip': // 仅VIP用户可访问
      if (userRole === 'vip') { next(); }
        else  { next({path: '/403'}); } 
      break;
    case 'admin': // 仅管理员可访问
      if (userRole === 'admin') { next(); } 
        else {next({ path: '/403' }); } 
      break;
    default:
      next();
  }
});


export default router;