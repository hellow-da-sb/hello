import apiClient from './api.js';

// 获取视频列表
export function getVideoList() {
  return apiClient.get('/videos', { useCache: true });
}
// 获取单个视频详情
export function getVideoDetail(videoId) {
  return apiClient.get(`/videos/${videoId}`,{ useCache: true });
}
// 获取视频缓存
export function getVideoCache(videoId) {
  return apiClient.get(`/videos/${videoId}/cache`, { useCache: true });
}
// 获取视频
export function getVideo(videoId) {
  return apiClient.get(`/videos/${videoId}`);
}
// 上传视频
export async function apiUploadVideo(formData) {
  return apiClient.post('/videos/upload', formData);
}
//上传视频分块
export function uploadVideo(formData) {
  return apiClient.post('/videos/upload/chunk', formData);
}
//上传视频封面
export function apiUploadThumbnail(formData) {
  return apiClient.post('/videos/upload/thumbnail', formData);
}
// 删除视频
export function deleteVideo(videoId) {
  return apiClient.delete(`/videos/${videoId}`);
}
// 更新视频信息
export function updateVideo(videoId, data) {
  return apiClient.put(`/videos/${videoId}`, data);
}


