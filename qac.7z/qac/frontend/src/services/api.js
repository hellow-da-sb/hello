// 定义外部 URL 作为全局变量
const EXTERNAL_URL = import.meta.env.VITE_API_URL;
import axios from 'axios';
import fetchVideoData from '@/utils/cacheMiddleware';
import router from '../router';

// 创建 Axios 实例
const apiClient = axios.create({
  baseURL: EXTERNAL_URL, 
  timeout: 5000, // 请求超时时间
  headers: {
  }
});

fetchVideoData(apiClient);


// 请求拦截器逻辑
const requestInterceptor = (config) => {
  const token = localStorage.getItem('token');
  
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`;
  }
  return config;
};

// 响应拦截器逻辑
const responseInterceptor = (response) => {
  return response;
};

const errorInterceptor = (error) => {
  if (error.response) {
    console.error('响应错误:', error.response.status);
    if (error.response.status === 401) {
      console.log('身份验证失败，请重新登录' + error.response.message);
      router.push('/login');
    }
  } else if (error.request) {
    console.error('未收到响应:', error.request);
  } else {
    console.error('请求配置错误:', error.message);
  }
  return Promise.reject(error);
};

// 添加拦截器
apiClient.interceptors.request.use(requestInterceptor, (error) => Promise.reject(error));
apiClient.interceptors.response.use(responseInterceptor, errorInterceptor);
export default apiClient;
