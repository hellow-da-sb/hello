import apiClient from './api.js';

// 登录方法
export const loginUser = async (credentials) => {
        return await apiClient.post('/auth/login', credentials);      
};
// 注册方法
export const registerUser = async (userData) => {  
        return await apiClient.post('/auth/register', userData); 
};
// 获取用户数据
export const getUserData = () => apiClient.get('/users/profile');
// 更新用户数据
export const updateUserData = (data) => apiClient.put('/users/profile', data);
// 删除用户
export const deleteUser = (userId) => apiClient.delete(`/users/${userId}`);
// 登出方法
export const Loginout = async () => {
         return await apiClient.post('/auth/logout');
}
