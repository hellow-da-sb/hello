<template>
    <div class="container"> 
        <div class="header">
            <h1>欢迎来到我的个人中心</h1>
        </div>
        <div class="content">
            <h2>用户信息</h2>
            <p>用户名: {{ userInfo.username }}</p>
            <p>年龄: {{ userInfo.age }}</p>
        </div>    
    </div>
</template>
<script setup>
import { useStore } from 'vuex'
import { computed, reactive } from 'vue'
const store = useStore()
const userInfo = computed(() => store.state.user.userInfo)
</script>