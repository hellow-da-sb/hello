<template>
    <div id="video-Card">
      <LoginCard />
    </div>
  </template>
  
  <script setup>
  import LoginCard from '../components/user/loginCard.vue';
  </script>

  <style scoped>
  #video-Card {
    display: flex;          /* 启用flex布局 */
    justify-content: center; /* 水平居中 */
    align-items: center;    /* 垂直居中 */
    min-height: 100vh;      /* 确保容器至少占满视口高度 */
  }
  </style>
  
  
  