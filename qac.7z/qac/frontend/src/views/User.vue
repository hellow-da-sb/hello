<template>
    <h1>用户中心</h1>
    
    <ul>
      <li v-for="[key, value] in Object.entries(userdateInfo)" :key="key">
        {{ key }}: 
        <button type="button" v-if="editingKey !== key" @click="() => editingKey = key">{{value}}</button>
        <input v-else type="text" v-model="userdateInfo[key]" @blur="editingKey = null">
      </li>
    </ul>
    <button type="button" @click="updateUser">提交修改</button>
</template>
<script setup>
import { useStore,mapMutations} from 'vuex'
import { computed, reactive, ref } from 'vue'
import {getUserData,updateUserData} from '@/services/user.js'

const store = useStore()
const userInfo = computed(() => store.state.user.userInfo)
const userdateInfo = reactive({
   username: userInfo.value.username,
   email: userInfo.value.email,
   phone: userInfo.value.phone,
   gender: userInfo.value.gender,
   birthday: userInfo.value.birthday,
   avatar: userInfo.value.avatar,
   role: userInfo.value.role,
   createdAt: userInfo.value.createdAt,
   videos : userInfo.value.videos,
   comments : userInfo.value.comments,

})
const editingKey = ref(null)
// 更新用户信息
const updateUser = async () => {
  try {
    console.log (userdateInfo)
    const res = await updateUserData(userdateInfo)
     store.commit('user/setUserInfo', res.data)
  } catch (error) {
    console.error('更新用户信息时出错:', error)
  }
}

// 获取用户信息
const GettsUser = async () => {
  try {
    const res = await getUserData()
    store.commit('user/setUserInfo', res.data)
  } catch (error) {
    console.error('获取用户信息时出错:', error)
  }
}
GettsUser()
</script>