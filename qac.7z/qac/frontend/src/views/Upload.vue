<template> 
  <div class="container p-4">
    <h2 class="mb-4">视频上传表单</h2>
    <form @submit.prevent>
      <!-- 标题输入 -->
      <div class="mb-3">
        <label for="title" class="form-label">标题</label>
        <input type="text" class="form-control" id="title" v-model="videoData.title">
      </div>
      <!-- 标签输入 -->
      <div class="mb-3">
        <label for="tags" class="form-label">标签</label>
          <div class="tag-container d-flex align-items-center flex-wrap gap-2">
              <span v-for="(tag, index) in videoData.tags" class="tag badge bg-secondary">{{ tag }} <button @click="removeTag(index)" class="btn-close"></button></span>
              <button class="btn btn-primary" v-if="istagInput == false" @click="showTagInput">请输入标签</button>
              <input type="text" class="form-control" v-else v-model="tagInput" @keyup.enter="addTag" @blur="addTag" style="max-width: 150px;"> 
          </div>
      </div>
      <!-- 简介输入 -->
      <div class="mb-3">
        <label for="description" class="form-label">视频简介</label>
        <textarea class="form-control" id="description" v-model="videoData.description" rows="4"></textarea>
      </div>
      <!-- 视频上传 -->
      <div class="mb-3">
        <label for="video" class="form-label">上传视频</label>
        <div class="d-flex align-items-center">
         <VideoUpload @video="handlevideo" @metadata="handleMetadata"  />
        </div>
        <div class="progress mt-2" v-if="uploadProgress > 0">
          <div class="progress-bar" :style="{ width: uploadProgress + '%' }" :aria-valuenow="uploadProgress" aria-valuemin="0" aria-valuemax="100">{{ uploadProgress }}%</div>
        </div>
      </div>
      <!-- 封面上传 -->
      <div class="mb-3">
        <label for="thumbnail" class="form-label">封面上传</label>
        <div class="thumbnail-container flex-content-center" >     
            <div class="d-flex justify-content-between w-100">
                <img v-if="thumbnailUrl" :src="thumbnailUrl" alt="封面预览" class="upload-img" style="max-width: 40%;" @click="handleUploadClick" > 
                <button v-if="videoUrl" @click="captureThumbnail" class="btn btn-secondary mt-2" style="max-width: 15%;">截取封面</button>
                <input type="file"  ref="thumbnailInput" id="thumbnail" @change="handleThumbnailUpload" accept="image/*" style="display: none;">
                <video 
                  v-if="videoUrl" 
                  ref="videoElement" 
                  :src="videoUrl" 
                  controls 
                  class="mt-2" 
                  style="max-width:40%;"
                  @loadeddata="captureThumbnail">
                </video>
            </div>
              <div  v-if="!thumbnailUrl" for="thumbnail" class="btn btn-{{ thumbnailUrl ? 'secondary' : 'primary' }} form-control upload-area mt-2 " @click="handleUploadClick">
                  点击上传封面
                  <input type="file"  ref="thumbnailInput" id="thumbnail" @change="handleThumbnailUpload" accept="image/*" style="display: none;">
              </div>
              <div v-if="thumbnailError" class="text-danger mt-2">{{ thumbnailError }}</div>
        </div>
      </div>
      <button type="submit" class="btn btn-primary" @click="submitForm">提交</button>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useStore } from 'vuex';
import VideoUpload from '@/components/upload/videoUpload.vue';

// 初始化Vuex存储
const store = useStore();
// 封面错误信息
const thumbnailError = ref('');
// 封面上传状态
const isThumbnailUploading = ref(false);
// 上传进度
const uploadProgress = ref(0); 
// 封面文件
const thumbnailFile = ref(null);
// 封面预览URL
const thumbnailUrl = ref('');
// 视频URL
const videoUrl = ref('');
// 视频数据
const videoData = ref({ title: '', tags: [], description: '', videopath: '', videoID: '', category:'aa' });
// 标签输入值
const tagInput = ref('');
// 标签输入框显示状态
const istagInput = ref(false);

// 添加标签
const addTag = () => {
  if (tagInput.value) {
    videoData.value.tags = [...new Set([...videoData.value.tags, tagInput.value])];
    tagInput.value = '';
    istagInput.value = false; 
  }
};

// 处理视频元数据
const handleMetadata = (metadata) => {
  videoData.value.metadata = metadata; 
};

// 处理视频选择
const handlevideo = (file) => {
  videoUrl.value = URL.createObjectURL(file);
};

// 移除标签
const removeTag = (index) => {
  videoData.value.tags.splice(index, 1);
};

// 显示标签输入框
const showTagInput =()=>{ istagInput.value = true};

// 封面输入框引用
const thumbnailInput = ref(null); 
// 视频元素引用
const videoElement = ref(null); 

// 触发封面选择
const handleUploadClick = () => {
  thumbnailInput.value.click(); 
};

// 处理封面上传和压缩
const handleThumbnailUpload = async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  thumbnailError.value = ''; 
  try {
    const img = new Image();
    img.src = URL.createObjectURL(file);
    await new Promise(resolve => img.onload = resolve);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    // 裁剪为16:9
    const [w, h] = [img.width, img.height];
    const [targetW, targetH] = [h * (16/9), w / (16/9)];
    canvas.width = w > targetW ? targetW : w;
    canvas.height = h > targetH ? targetH : h;
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.9));
    URL.revokeObjectURL(img.src);
    // 压缩文件
    const worker = new Worker(new URL('@/utils/imageCompressor.worker.js', import.meta.url));
    worker.postMessage(blob);
    const compressed = await new Promise((resolve, reject) => {
      worker.onmessage = (e) => e.data.error ? reject(e.data.error) : resolve(e.data);
    });
    if (compressed.size > 5 * 1024 * 1024) {
      thumbnailError.value = '文件过大，请选小图';
      return;
    }
    thumbnailFile.value = compressed;
    thumbnailUrl.value = URL.createObjectURL(compressed);
  } catch (error) {
    thumbnailError.value = '封面处理失败，请重试';
  }
};

// 提交表单
const submitForm = async () => {
  videoData.value.videoID = store.state.videos.videoUpload.videoID;
  if (!videoData.value.videoID) {
    thumbnailError.value = '请先上传视频';
    return;
  }
  const formData = new FormData();
  formData.append('thumbnail', thumbnailFile.value);
  formData.append('videoID', videoData.value.videoID); 
  try {
    const res = await store.dispatch('videos/uploadThumbnail', formData);
    videoData.value.videopath = res.data?.videopath;
    if (!videoData.value.videopath) throw new Error('封面上传失败');
    if (!['title', 'tags', 'description', 'videopath', 'videoID'].every(k => videoData.value[k])) {
      thumbnailError.value = '请填全信息';
      return;
    }
    await store.dispatch('videos/uploadVideo', videoData.value); 
    alert('提交成功！'); 
    videoData.value = { title: '', tags: [], description: '', videopath:'', videoID: '', category: '未分类' };
    thumbnailError.value = '';
  } catch (error) {
    thumbnailError.value = `提交失败：${error.message || '请重试'}`;
  }
};

// 截取封面
const captureThumbnail =async () => {
  if (!videoUrl.value || !videoElement.value) {
    thumbnailError.value = '请先上传视频';
    return;
  }
  try {
    const video = videoElement.value;
    if (video.readyState < 2) return setTimeout(captureThumbnail, 20);
    if (video.currentTime < 0.5) {
      video.currentTime = 0.5;
      return setTimeout(captureThumbnail, 200);
    }
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 360;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    canvas.toBlob(async (blob) => {
      const worker = new Worker(new URL('@/utils/imageCompressor.worker.js', import.meta.url));
      worker.postMessage(blob);
      const compressed = await new Promise((resolve, reject) => {
        worker.onmessage = (e) => e.data.error ? reject(e.data.error) : resolve(e.data);
      });
      if (compressed.size > 5 * 1024 * 1024) {
        thumbnailError.value = '文件过大';
        return;
      }
      thumbnailFile.value = compressed;
      thumbnailUrl.value = URL.createObjectURL(compressed);
    }, 'image/jpeg', 0.9);
  } catch (error) {
    thumbnailError.value = `截取失败: ${error.message}`;
  }
};
</script>

<style scoped>
.upload-area {
  border: 2px dashed #ccc;
  border-radius: 8px;
  padding: 20px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s;
  margin: 10px 0;
}
.upload-img {
  border: 2px dashed #ccc;
  border-radius: 8px;
  padding: 5px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s;
  margin: 5px 0;
}
.progress {
  height: 20px;
}
.progress-bar {
  transition: width 0.3s ease;
}
.tag-container {
  gap: 8px;
}
.tags {
  cursor: pointer;
  user-select: none;
}
.container {
  max-width: 800px; 
  margin-left: auto;
  margin-right: auto;
}
</style>

