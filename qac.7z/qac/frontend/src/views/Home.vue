<template>
  <div>
      <h1>首页</h1>
        <div class="row row-cols-2 row-cols-md-4 g-4">
            <RouterLink
              v-for="video in videosList"
              :to="'/video/' + video.videoId"
              class="col text-decoration-none"
              target="_blank"
              :key="video.id"
              >   
              <videoCard :video="video" />
            </RouterLink>
      </div>
  </div>
</template>
<script setup>
import { ref, reactive } from 'vue'
import { useStore } from 'vuex'
import videoCard from '../components/videoCard.vue'
const store = useStore()
store.dispatch('videos/fetchVideos')//  视频列表 
const videosList = reactive(store.state.videos.videos);
</script>