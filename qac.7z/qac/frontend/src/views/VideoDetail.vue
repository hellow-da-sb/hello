<template>
  <div class="container mt-4">    
    <div class="mt-4">
      <VideoPlay :videoUrl="video.videoUrl" />
    </div>
    <div class="card shadow-sm">
        <h2>详情区</h2>
        <h2>评论区</h2>
    </div>
  </div>
</template>

<script setup>
import VideoPlay from '../components/videoPlay.vue'
import { ref } from 'vue'
import { useStore } from 'vuex'
import {  useRoute } from 'vue-router'
const route = useRoute()
const store = useStore()

const findVideoById = (id, videos) => {
  for (const key in videos) {
    if (videos[key].videoId === id) {
      return videos[key];
    }
  } return null;
};
const videoId = route.params.id;
const videos = store.state.videos.videos;
const video = findVideoById(videoId, videos);
const videoUrl = ref(video?.videoUrl || '')

</script>