// 导出用户状态管理模块
import { loginUser, registerUser, getUserData, updateUserData, deleteUser, Loginout } from '../services/user.js';
 export default {
  // 状态对象，存储模块的所有状态
  state() {
    return { 
        isLogin: false,
        userInfo: {
          token: null,
          username: null,
          email: null,
          phone: null,
          avatar: null,
          gender: null,
          role: null,
          videos: [],
          comments: [],
          createdAt: null,
          __v: 0
        }
    };
   
  },
  // 变更函数集合，用于同步修改状态
  mutations: {
      // 设置用户信息
      setUserInfo(state, info) {
        state.userInfo = info;
      },
      // 设置登录状态
      setLoginStatus(state, isLogin) {
        state.isLogin = isLogin;
      }
  },
  // 异步变更函数集合，用于异步修改状态
  actions: {
    // 异步登录
    async login({ commit }, credentials) {
          const response = await loginUser(credentials);
          const user = response.data;
          if (user.token) {
              localStorage.setItem('token', user.token);
          } 
          // 存储用户信息到本地存储或其他持久化存储中
          commit('setUserInfo', user);
          commit('setLoginStatus', true);console.log('登录成功!');
          return response;
          
  },
  // 异步注册
  async register({ commit }, userData) {
          const response = await registerUser(userData);
          const user = response.data;
          if(user.token){
            localStorage.setItem('token', user.token);
          }
          commit('setUserInfo', user);
          commit('setLoginStatus', true);
          return response;
  },
  // 异步获取用户信息
  async fetchUserInfo({ commit }) {
        const response = await getUserData();
        const user = response.data;
        commit('setUserInfo', user);
        commit('setLoginStatus', true);
        return response;
},
// 异步登出
async logout({ commit }) {
        const response = await Loginout();
        commit('setUserInfo', {});
        commit('setLoginStatus', false);
        return response;
},
// 异步修改用户信息
async updateUserInfo({ commit }, updatedInfo) {
        const response = await updateUserData(updatedInfo);
        const user = response.data;
        commit('setUserInfo', user);
        return response;
},
// 异步删除用户
async deleteUser({ commit }, userId) {
        await deleteUser(userId);
        commit('setUserInfo', {});
        commit('setLoginStatus', false);
        return { message: '用户已删除' };
}
    
  },
  // 计算属性集合，用于派生状态
  getters: {
    // 获取登录状态
    isUserLoggedIn: (state) => state.isLogin,
    // 获取用户信息
    getUserInfo: (state) => state.userInfo
  }
};
