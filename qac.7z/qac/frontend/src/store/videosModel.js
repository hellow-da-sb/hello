import { getVideoList, getVideoDetail, apiUploadVideo, apiUploadThumbnail,deleteVideo, updateVideo ,uploadVideo} from '../services/video.js';
const UPLAOD_URL = import.meta.env.VITE_UPLOAD_URL;

export default {
    state() {
      return { 
        videos: [], // 视频列表
        total: 0,
        page: 1,
        limit: 20,
        currentVideo: null, // 当前播放的视频
        videoMetadata: null, // 视频元数据
        videoUpload:{
            chunkIndex: 0, // 当前分块索引
            totalChunks: 0, // 总分块数
            videoID: null, // 视频ID
            title: null, // 视频标题
            description: null, // 视频描述
            category: null, // 视频分类
            thumbnail: null, // 缩略图
            tags: null, // 标签
            thumbnailUrl: null, // 缩略图URL
            videoUrl: null, // 视频URL
        },
        filter: { // 筛选条件
          category: 'all',
          keyword: ''
        }
      };
    },
    mutations: {
      // 设置视频列表
      setVideos(state, videos) {
        state.videos = videos;
      },
      // 设置当前播放的视频
      setCurrentVideo(state, video) {
        state.currentVideo = video;
      },
      // 设置视频上传状态（修改为合并模式）
      setVideoUpload(state, videoUpload) {
        state.videoUpload = { ...state.videoUpload, ...videoUpload }; // 合并原有状态和新状态
      },
      // 更新筛选条件
      updateFilter(state, filter) {
        state.filter = { ...state.filter, ...filter };
      },
      // 设置视频元数据到全局状态
      setVideoMetadata(state, metadata) {
        state.videoMetadata = metadata; // 添加videoMetadata字段存储元数据
      }
    },
    actions: {
      // 异步获取视频列表
      async fetchVideos({ commit, state }) {
        try {
          const response = await getVideoList();
          const videos = response.data.videos
          const processedVideos = videos.map(video => ({ 
            ...video, 
            coverUrl: `${UPLAOD_URL}${video.filePath}/thumbnail.png`, // 封面URL
            videoUrl: `${UPLAOD_URL}${video.filePath}/video.mp4`     // 视频播放URL
          }));
          commit('setVideos', processedVideos);
        } catch (error) {
          console.error('获取视频列表失败:', error);
        }
      },
      // 异步上传视频
      async uploadVideo({ commit, state },videoData) {
        try {
          return await apiUploadVideo(videoData);
        } catch (error) {
          console.error('上传视频失败:', error);
        }
      },
      // 异步上传视频分块（修改数据提取和提交逻辑）
      async uploadVideoChunk({ commit, state }, formData) {
        try {
          // 调用上传视频分块的API
          const response = await uploadVideo(formData);
          const { videoID, chunkIndex, totalChunks, videoUrl } = response.data;
          const Chunk = { videoID, chunkIndex, totalChunks, videoUrl };
          commit('setVideoUpload', Chunk);
          return response;
        } catch (error) {
          console.error('上传视频分块失败:', error);
        }
      },
      // 异步上传视频缩略图
      async uploadThumbnail({ commit }, formData) {
        try {
          const response = await apiUploadThumbnail(formData);
          const thumbnailUrl = response.data;
          commit('setVideoUpload', { thumbnailUrl }); // 提交缩略图URL到状态
          return response;
        }catch (error) {
          console.error('上传视频封面失败:', error);
        }
      },
      // 异步删除视频
      async deleteVideo({ commit, state }, videoId) {
        try {
          await deleteVideo(videoId);
          commit('setVideos', state.videos.filter(video => video._id !== videoId));
        } catch (error) {
          console.error('删除视频失败:', error);
        }
      },
      // 异步更新视频信息
      async updateVideo({ commit, state }, { videoId, data }) {
        try {
          const response = await updateVideo(videoId, data);
          const updatedVideo = response.data;
          const newVideos = state.videos.map(video => 
              video._id === videoId ? updatedVideo : video
          );
          commit('setVideos', newVideos);
        } catch (error) {
          console.error('更新视频信息失败:', error);
        }
      },
      // 异步获取单个视频详情
      async fetchVideoDetail({ commit }, videoId) {
        try {
          const response = await getVideoDetail(videoId);
          const video = response.data;
          commit('setCurrentVideo', video);
        } catch (error) {
          console.error('获取单个视频详情失败:', error);
        }
      }
    },
    getters: {
      // 筛选后的视频列表
      filteredVideos: (state) => {
        return state.videos.filter(video => {
          const matchesCategory = state.filter.category === 'all' || video.category === state.filter.category;
          const matchesKeyword = video.title.toLowerCase().includes(state.filter.keyword.toLowerCase());
          return matchesCategory && matchesKeyword;
        });
      },
      chunkUpkoad:  (state) =>{
        return state.chunkUpkoad
      },
      // 当前播放视频的详细信息
      currentVideoDetails: (state) => {
        return state.currentVideo ? state.videos.find(video => video._id === state.currentVideo._id) : null;
      }
    }
  };