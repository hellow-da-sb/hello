import { createStore } from 'vuex';
import userModel from './userModel.js';
import videosModel from './videosModel.js';

const store = createStore({
  modules: {
    // 注册模块
    user: {
      ...userModel,
      namespaced: true
    },
    videos: {
      ...videosModel,
      namespaced: true
    }   
  }  
});

// 监听 Vuex 状态变化并存储到 localStorage
store.subscribe((mutation, state) => {
  localStorage.setItem('vuex', JSON.stringify(state));
});

// 页面加载时从 localStorage 恢复 Vuex 状态
if (localStorage.getItem('vuex')) {
  store.replaceState(JSON.parse(localStorage.getItem('vuex')));
}

export default store;
