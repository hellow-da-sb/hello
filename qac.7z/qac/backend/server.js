require('dotenv').config();
const connectDB = require('./config/db');
const app = require('./app');
const videodelet = require('./utils/videodelet');
const startServer = async () => {
  try {
    await connectDB();
    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => {
      console.log(`服务器运行在端口'http://localhost:${PORT}'`);
    });
  } catch (err) {
    console.error('服务器启动失败:', err.message);
    process.exit(1);
  }
videodelet;
};
startServer();
