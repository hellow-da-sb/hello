const User = require('../models/User');
const jwt = require('jsonwebtoken');
// 用户注册
exports.registerUser = async (req, res) => {
  console.log('收到注册请求:', req.body);
  const { username, email, password,phone } = req.body;
  console.log('用户名:', username, '邮箱:', email, '密码:', password)
  try {
    // 检查用户是否已存在
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: '用户已存在' });
    }
    // 创建新用户
    user = new User({ 
      username, 
      email, 
      password, 
      phone,
      role: '普通用户', 
      canUpload: true // 新增：默认允许上传
    });
    await user.save();
    // 生成JWT
    const payload = { user: { id: user.id } };
    jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' }, (err, token) => {
      if (err) throw err;
      res.json({ token });
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
};
// 用户登录
exports.loginUser = async (req, res) => {
  const { email, password } = req.body;
  console.log('登录请求:', req.body);
  if (!email || !password) {
    return res.status(400).json({ msg: '邮箱和密码是必填项' });
  }
  try {
    // 检查用户是否存在
    const user = await User.findOne({ email });
    if (!user) {
    return res.status(401).json({ msg: '用户不存在', email: email });
    }
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
    return res.status(401).json({ msg: '密码错误', email: email });
    }
    // 生成JWT
    const payload = { user: { id: user.id } };
    jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' }, (err, token) => {
      if (err) throw err;
      res.json({ token });
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('服务器错误');
  }
};

