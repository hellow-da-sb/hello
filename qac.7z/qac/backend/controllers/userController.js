const User = require('../models/User');

// 获取用户个人信息
exports.getUserProfile = async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ msg: '用户未认证' });
  }
  try {
    const user = await User.findById(req.user.id)
      .select('-password -_id')
      .populate('videos', 'title thumbnailUrl createdAt')
      .populate('comments', 'content videoId createdAt');
      
    user.phone = user.phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
    if (!user) return res.status(404).json({ msg: '用户不存在' });
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: '获取用户信息失败: ' + err.message });
  }
};

// 修改用户个人信息
exports.updateUserProfile = async (req, res) => {
  console.log('收到更新请求:', req.body);
  if (!req.user) {
    return res.status(401).json({ msg: '用户未认证' });
  }
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ msg: '用户不存在' });
    const updates = {};
    ['username', 'avatar', 'gender','age'].forEach(field => {
      if (req.body[field]) updates[field] = req.body[field];
    });
    
    const updatedUser = await User.findByIdAndUpdate(
      req.user.id,
      updates,
      { new: true, runValidators: true }
    );
    
    res.json(updatedUser);
  } catch (err) {
    res.status(500).json({ msg: '更新用户信息失败: ' + err.message });
  }
};

// 获取所有用户（管理员功能）
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    res.status(500).json({ msg: '获取用户列表失败: ' + err.message });
  }
};
