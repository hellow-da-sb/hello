const Video = require('../models/Video');
const Comment = require('../models/Comment');
const handleChunkUpload = require('../middlewares/videoUploadMiddleware');
const handleThumbnailUpload = require('../middlewares/thumbnailUploadMiddleware');
const path = require('path');
const Log = require('../models/Log');

// 提取公共错误处理函数
const handleControllerError = (res, err, message) => {
  console.error(message, err.message);
  res.status(500).json({ msg: `${message}: ${err.message}` });
};

//上传视频
exports.uploadVideo = async (req, res) => {
  try {
    console.log('收到的信息:',req.body);
    if (!req.body.title || !req.body.description || !req.body.tags || !req.body.videoID || !req.body.videopath || !req.body.category) {
      return res.status(400).json({ msg: '信息不完整，需要提供title、description、tags、videoID、videoPath、category' });
    } 
    if (!req.user?.id) {
      return res.status(401).json({ msg: '用户未认证，无法获取userId' });
    }
    
    const videoData = {
      videoId: req.body.videoID,  
      userId: req.user.id,
      title: req.body.title,
      description: req.body.description,
      filePath: req.body.videopath,
      tags: req.body.tags,
      category: req.body.category,
    };

    const newVideo = new Video(videoData);
    const savedVideo = await newVideo.save();
    res.status(201).json({ 
      success: true,
      message: '视频信息插入数据库成功',
      video: savedVideo
    });

  } catch (error) {
    console.log('数据库插入错误:', error);
    // 3. 处理唯一键冲突错误
    if (error.code === 11000) {
      return res.status(400).json({ msg: `视频ID ${req.body.videoId} 已存在，请勿重复提交` });
    }
    return res.status(500).json({ msg: '服务器错误：视频信息插入失败', error: error.message });
  }
}

//上传视频分片
exports.uploadVideoChunk = async (req, res) => {
    handleChunkUpload(req, res);
};

//上传视频缩略图
exports.uploadVideoThumbnail = async (req, res) => {
  handleThumbnailUpload(req, res);
};

//获取已发布视频（分页+筛选）
exports.getVideos = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const videos = await Video.find({ status: '已发布' })
      .sort({ createdAt: -1 }) // 按创建时间倒序排列
      .skip(skip)
      .limit(limit)
      .populate('userId', 'username avatar');

    res.json({
      total: await Video.countDocuments({ status: '已发布' }), // 总记录数
      page,
      limit,
      videos
    });
  }
  catch (err) {
    handleControllerError(res, err, '获取视频列表失败');
  }
};

// 获取单个视频详情
exports.getVideoDetails = async (req, res) => {
  
};

// 更新视频信息
exports.updateVideo = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ msg: '用户未认证' });
    }
    const video = await Video.findById(req.params.id);
    if (!video) return res.status(404).json({ msg: '视频不存在' });
    if (video.user.toString() !== req.user.id) return res.status(403).json({ msg: '无权限修改' });

    const { title, description, tags } = req.body;
    video.title = title || video.title;
    video.description = description || video.description;
    video.tags = tags?.split(',') || video.tags;

    await video.save();
    res.json(video);
  } catch (err) {
    res.status(500).json({ msg: '更新视频失败: ' + err.message });
  try {
    if (!req.file) {
      return res.status(400).json({ msg: '未上传视频文件' });
    }
    const videoPath = req.file.path.replace(/\\/g, '/'); // 转换Windows路径分隔符
    const { title, description, tags } = req.body;
    const newVideo = new Video({ 
      title, 
      description, 
      tags: tags?.split(','), 
      videoUrl: videoPath, 
      user: req.user.id 
    });
    const savedVideo = await newVideo.save();
    res.status(201).json(savedVideo);
  } catch (err) {
    res.status(500).json({ msg: '上传视频失败: ' + err.message });
  }
  }};

//删除视频（含关联评论）
exports.deleteVideo = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ msg: '用户未认证' });
    }
    const video = await Video.findById(req.params.id);
    if (!video) return res.status(404).json({ msg: '视频不存在' });
    if (video.user.toString()!== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ msg: '无权限删除' });
    }
    // 删除视频文件
    // 删除评论
    await Comment.deleteMany({ video: req.params.id });
    await video.remove();
    res.json({ msg: '视频删除成功' });
  }
  catch (err) {
    res.status(500).json({ msg: '删除视频失败:'+ err.message });
  }
}