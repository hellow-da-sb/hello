const Comment = require('../models/Comment');
const Video = require('../models/Video');

// 创建评论/回复
exports.createComment = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ msg: '用户未认证' });
    }
    const { content, videoId, parentCommentId } = req.body;
    const video = await Video.findById(videoId);
    if (!video) return res.status(404).json({ msg: '视频不存在' });

    const comment = new Comment({
      content,
      video: videoId,
      user: req.user.id,
      parentComment: parentCommentId
    });
    await comment.save();
    res.status(201).json(await comment.populate('user', 'username avatar'));
  } catch (err) {
    res.status(500).json({ msg: '创建评论失败: ' + err.message });
  }
};

// @desc    获取视频所有评论（含分页）
exports.getVideoComments = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const comments = await Comment.find({ video: req.params.videoId })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('user', 'username avatar')
      .populate({ path: 'parentComment', populate: { path: 'user', select: 'username avatar' } });

    res.json(comments);
  } catch (err) {
    res.status(500).json({ msg: '获取评论失败: ' + err.message });
  }
};

// @desc    删除评论（仅作者或管理员）
exports.deleteComment = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ msg: '用户未认证' });
    }
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ msg: '评论不存在' });

    // 修正权限检查：使用用户模型中的role字段
    if (comment.user.toString() !== req.user.id && req.user.role !== '管理员') {
      return res.status(403).json({ msg: '无权限删除' });
    }

    await comment.deleteOne();
    res.json({ msg: '评论已删除' });
  } catch (err) {
    res.status(500).json({ msg: '删除评论失败: ' + err.message });
  }
};
