const express = require('express');
const router = express.Router();
const { registerUser, loginUser } = require('../controllers/authController');

// @desc注册用户
// @route POST /api/auth/register
// @access 公开
router.post('/register', registerUser);

// @desc登录用户
// @route POST /api/auth/login
// @access 公开
router.post('/login', loginUser);

// @desc登出用户
// @route POST /api/auth/logout
// @access 公开
router.post('/logout', (req, res) => {
    res.clearCookie('token');
    res.json({ message: '登出成功' });
})
module.exports = router;