const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const { getUserProfile, updateUserProfile, getAllUsers } = require('../controllers/userController');

// @desc    获取用户个人信息
// @route   GET /api/users/profile
// @access  私有
router.get('/profile', auth, getUserProfile);

// @desc    更新用户个人信息
// @route   PUT /api/users/profile
// @access  私有
router.put('/profile', auth, updateUserProfile);

// @desc    获取所有用户（管理员）
// @route   GET /api/users
// @access  私有（管理员）
router.get('/', auth, getAllUsers);

module.exports = router;