const express = require('express');
const router = express.Router();
const {  createComment,getVideoComments,deleteComment } = require('../controllers/commentController');

// @desc    创建评论
// @route   POST /api/comments
// @access  私有
router.post('/', createComment);

// @desc    获取视频所有评论（含分页）
// @route   GET /api/comments/video/:videoId
// @access  公开
router.get('/video/:videoId', getVideoComments);

// @desc    删除评论（仅作者或管理员）
// @route   DELETE /api/comments/:id
// @access  私有
router.delete('/:id', deleteComment);

module.exports = router;