const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const { uploadVideo,getVideos, deleteVideo,getVideoDetails,uploadVideoChunk,uploadVideoThumbnail } = require('../controllers/videoController');

// @desc    上传视频
// @route   POST /api/videos/upload
// @access  私有
router.post('/upload', auth, uploadVideo);

// @desc    上传视频分片
// @route   POST /api/videos/upload/chunk
// @access  私有
router.post('/upload/chunk',auth, uploadVideoChunk);

// @desc    上传视频缩略图
// @route   POST /api/videos/upload/thumbnail
// @access  私有
router.post('/upload/thumbnail',uploadVideoThumbnail);

// @desc    获取视频列表
// @route   GET /api/videos
// @access  公开
router.get('/', getVideos);

// @desc    获取单个视频详情
// @route   GET /api/videos/:id
// @access  公开
router.get('/:id', getVideoDetails);

// @desc    删除视频
// @route   DELETE /api/videos/:id
// @access  私有
router.delete('/:id', auth, deleteVideo);

module.exports = router;