module.exports = {
  jwt: {
    secret: process.env.JWT_SECRET,
    expiresIn: '7d' // 令牌有效期7天
  },
  bcrypt: {
    saltRounds: 10 // 密码哈希盐轮数
  }
};