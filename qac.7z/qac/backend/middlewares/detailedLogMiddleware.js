const Log = require('../models/Log');
// 详细日志中间件
module.exports = (req, res, next) => {
  const start = Date.now();
  const originalSend = res.send;

  // 记录请求信息
  const requestLog = {
    method: req.method,
    url: req.url,
    headers: req.headers,
    body: req.body,
    timestamp: new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })
  };

  res.send = function (body) {
    // 记录响应信息
    const end = Date.now();
    const responseLog = {
      statusCode: res.statusCode,
      headers: res.getHeaders(),
      body: body,
      responseTime: end - start,
      timestamp: new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })
    };

    // 合并请求和响应日志
    const fullLog = {
      ...requestLog,
      ...responseLog
    };

    // 保存日志到数据库
    const log = new Log({ message: JSON.stringify(fullLog) });
    log.save().catch(err => console.error('保存详细日志失败:', err));

    originalSend.call(this, body);
  };

  next();
};