//视频处理
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid'); 

// 配置 multer 使用内存存储（处理分片）
const storage = multer.memoryStorage();
const upload = multer({ storage });

// 处理分片上传的中间件
const handleChunkUpload = (req, res) => {
  upload.fields([
    { name: 'chunk', maxCount: 1 }, // 分片文件字段
    { name: 'chunkIndex', maxCount: 1 }, // 分片索引（文本字段）
    { name: 'totalChunks', maxCount: 1 }, // 总分片数（文本字段）
    { name: 'videoID', maxCount: 1 }, // 文件 ID（文本字段，可选）
    { name: 'metadata', maxCount: 1 } // 元数据字段
  ])(req, res, (err) => {
    if (err) {
      return res.status(500).json({ 
        success: false, 
        message: '分片上传处理出错',
        error: err.message,
        chunkIndex: req.body?.chunkIndex
      });
    }

    const chunkFile = req.files?.chunk?.[0];
    const chunkIndex = req.body?.chunkIndex;
    const totalChunks = req.body?.totalChunks;
    const metadata = req.body?.metadata;
    let videoID = req.body?.videoID || uuidv4();

    if (!chunkFile || !chunkIndex || !totalChunks) {
      console.log('必要字段缺失');
      return res.status(400).json({ 
        success: false, 
        message: '缺少必要的分片信息（chunk、chunkIndex、totalChunks）',
        chunkIndex: chunkIndex
      });
    }

    try {
      // 创建存储目录（使用生成的videoID）
      const dateDir = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const videoDir = path.join(__dirname, '../uploads', dateDir, videoID);
      fs.mkdirSync(videoDir, { recursive: true });

      // 如果是第一个分片且包含元数据，保存元数据
      if (chunkIndex === '0' && metadata) {
        const metadataPath = path.join(videoDir, 'metadata.json');
        fs.writeFileSync(metadataPath, metadata);
      }

      // 保存分片文件（使用生成的videoID）
      const chunkPath = path.join(videoDir, `chunk_${chunkIndex}`);
      fs.writeFileSync(chunkPath, chunkFile.buffer);
      // 保存分片索引信息
      const indexPath = path.join(videoDir, 'index.json');
      let indexData = {};
      if (fs.existsSync(indexPath)) {
        indexData = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
      }
      indexData[chunkIndex] = true;
      try {
        fs.writeFileSync(indexPath, JSON.stringify(indexData));
      } catch (indexError) {
        console.error(`分片索引信息 ${indexPath} 保存失败:`, indexError);
        return res.status(500).json({ 
          success: false, 
          message: '分片索引信息保存失败',
          error: indexError.message,
          chunkIndex: chunkIndex
        });
      }

      console.log(`接收分片：${videoID} - 第 ${chunkIndex} 片（共 ${totalChunks} 片）`);
      // 返回成功响应（包含生成的videoID）
      res.status(200).json({ 
        success: true, 
        message: `分片 ${chunkIndex} 接收成功`,
        videoID, // 返回生成的videoID
        chunkIndex,
        totalChunks
      });

      // 检查是否所有分片都已接收
      const allChunksReceived = Object.keys(indexData).length === parseInt(totalChunks);
      if (allChunksReceived) {
        // 验证完整性（检查分片数量是否正确）
        const expectedChunks = Array.from({ length: parseInt(totalChunks) }, (_, i) => i.toString());
        const missingChunks = expectedChunks.filter(index => !indexData[index]);
        const isValid = missingChunks.length === 0;
        if (isValid) {
          console.log(`视频 ${videoID} 传输完成，完整性验证通过`);
          // 合并分片并保存完整视频文件
          const videoPath = path.join(videoDir, 'video.mp4');
          const chunks = expectedChunks.map(index => path.join(videoDir, `chunk_${index}`));
          const mergedChunks = chunks.map(chunk => fs.readFileSync(chunk));
          fs.writeFileSync(videoPath, Buffer.concat(mergedChunks));
          chunks.forEach(chunk => fs.unlinkSync(chunk)); // 删除分片文件       
          console.log(`视频 ${videoID} 合并完成`);
        } else {
          console.log(`视频 ${videoID} 传输完成，但完整性验证失败，缺失分片索引: ${missingChunks.join(', ')}`);
        }
      }
    } catch (error) {
      return res.status(500).json({ 
        success: false, 
        message: '分片存储出错',
        error: error.message,
        chunkIndex: chunkIndex,
        videoID
      });
    }
  });
};

module.exports = handleChunkUpload;