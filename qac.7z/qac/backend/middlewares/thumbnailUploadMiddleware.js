const multer = require('multer');
const fs = require('fs');
const path = require('path');

const storage = multer.memoryStorage();
const upload = multer({ storage });

const handleThumbnailUpload = (req, res) => { 
  upload.fields([
    { name: 'thumbnail', maxCount: 1 },
    { name: 'videoID', maxCount: 1 }
  ])(req, res, (err) => {
    if (err) {
      return res.status(500).json({ 
        success: false, 
        message: '缩略图上传处理出错',
        error: err.message
      });
    }
    const thumbnailFile = req.files?.thumbnail?.[0];
    const videoID = req.body?.videoID?.trim();

    if (!thumbnailFile || !videoID) {
      return res.status(400).json({ 
        success: false, 
        message: '缺少必要字段：需要提供thumbnail文件和videoID'
      });
    }

    try {
      // 生成最近10天的日期目录列表（格式YYYYMMDD）
      const dateList = Array.from({ length: 10 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - i);
        return date.toISOString().slice(0, 10).replace(/-/g, '');
      });

      // 按顺序检索最近10天的目录是否存在目标videoID目录
      const targetDateDir = dateList.find(dateDir => {
        const checkPath = path.join(__dirname, '../uploads', dateDir, videoID);
        return fs.existsSync(checkPath);
      });

      if (!targetDateDir) {
        return res.status(404).json({ 
          success: false, 
          message: `最近10天内未找到videoID为${videoID}的视频目录，放弃存储`
        });
      }

      // 使用找到的日期目录作为存储路径
      const videoDir = path.join(__dirname, '../uploads', targetDateDir, videoID);
      const fileExt = path.extname(thumbnailFile.originalname)||'.png';
      const thumbnailPath = path.join(videoDir, `thumbnail${fileExt}`);
      
      fs.writeFileSync(thumbnailPath, thumbnailFile.buffer);

      
      const videopath = `/uploads/${targetDateDir}/${videoID}`;

      res.status(200).json({ 
        success: true, 
        message: `缩略图已存储至${targetDateDir}目录`,
        videopath: videopath
      });
    } catch (error) {
      return res.status(500).json({ 
        success: false, 
        message: '缩略图存储失败',
        error: error.message,
        videoID
      });
    }
  });
};

module.exports = handleThumbnailUpload;