const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Log = require('../models/Log');

// 提取日志记录函数
const saveLog = async (message) => {
  try {
    const log = new Log({ message });
    await log.save();
  } catch (err) {
    console.error('保存日志失败:', err);
  }
};

module.exports = async (req, res, next) => {
  console.log('收到请求:', req.method, req.url);
  let token;
  
  if (req.headers.authorization?.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }
  
  if (!token) {
    await saveLog('未提供令牌，访问被拒绝');
    return res.status(401).json({ msg: '未提供令牌，访问被拒绝' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!decoded?.user?.id) {
      await saveLog('无效令牌,缺少用户ID');
      return res.status(401).json({ msg: '无效令牌,缺少用户ID' });
    }
    
    req.user = await User.findById(decoded.user.id).select('-password');
    await saveLog(`用户信息: ${req.user.id}`);
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ msg: '令牌已过期' });
    }
    res.status(401).json({ msg: '令牌无效，访问被拒绝' });
  }
};
