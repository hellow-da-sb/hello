const express = require('express');
const cors = require('cors');
const videoRoutes = require('./routes/videoRoutes');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const commentRoutes = require('./routes/commentRoutes');
const path = require('path');
const detailedLogMiddleware = require('./middlewares/detailedLogMiddleware');
const app = express();

// 中间件
app.use(cors());//  允许跨域
app.use(express.json({ limit: '50mb' })); //JSON 请求体限制为 50MB
app.use(express.urlencoded({ limit: '50mb', extended: true })); 
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));// 静态文件服务
app.use(detailedLogMiddleware);// 日志中间件

// 路由
app.use('/api/videos', videoRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/comments', commentRoutes);
module.exports = app;

