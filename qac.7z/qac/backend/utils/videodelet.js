const cron = require('node-cron');
const fs = require('fs');
const path = require('path');
const Video = require('../models/Video'); 

// 每天凌晨1点执行
const videodelet =  cron.schedule('0 1 * * *', async () => {
  console.log('开始清理未完成的视频...');

  const now = new Date();
  const tenDaysAgo = new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000);
  const twentyDaysAgo = new Date(now.getTime() - 20 * 24 * 60 * 60 * 1000);

  try {
    const videos = await Video.find({
      createdAt: { $lt: tenDaysAgo, $gte: twentyDaysAgo },
      isCompleted: false,
    });

    for (const video of videos) {

      const createdAt = new Date(video.createdAt);
      const dateDir = createdAt.toISOString().slice(0, 10).replace(/-/g, ''); 
      
      const videoDir = path.join(__dirname, '../uploads', dateDir, video._id.toString());

      if (fs.existsSync(videoDir)) {
        fs.rmdirSync(videoDir, { recursive: true });
        console.log(`已删除未完成的视频文件夹: ${video._id}`);
      }

      await Video.findByIdAndDelete(video._id);
    }

    console.log('清理完成');
  } catch (error) {
    console.error('清理未完成的视频失败:', error.message);
  }
});
module.exports = videodelet;