const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserSchema = new mongoose.Schema({
  // 用户唯一标识
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    unique: true
  },
  // 用户名
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  // 邮箱
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
   // 手机号
  phone: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
   // 密码
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  // 头像
  avatar: {
    type: String,
    default: 'default-avatar.png'
  },
   // 性别
  gender: {
    type: String,
    enum: ['男', '女', '未知'],
    default: '未知'
  },
   // 生日
  birthday: {date: Date},
   // 个性签名
  bio:{ type:String, maxlength: 160},
   // 角色
  role: {
    type: String,
    enum: ['普通用户', 'VIP用户', '创作者', '审核员', '管理员'],
    default: '普通用户'
  },
  // 关联视频ID（外键）
  videos: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Video'
  }],
   // 关联评论ID（外键）
  comments: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Comment'
  }],
   // 关联权限ID（外键）
  permissions: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'UserPermission'
  },
   // 关联会员ID（外键）
  membership: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Membership'
  },
  // 关联日志ID（外键）
  createdAt: {
    type: Date,
    default: Date.now,
    ref: 'Log'
  },

});



// 密码哈希预处理
UserSchema.pre('save', async function(next) {
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 10);
  }
  next();
});

// 方法：验证密码
UserSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

UserSchema.methods.toJSON = function() {
  const user = this;
  const userObject = user.toObject();

  delete userObject.password;

  return userObject;
};

module.exports = mongoose.model('User', UserSchema);