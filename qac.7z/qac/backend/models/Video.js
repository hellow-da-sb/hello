const mongoose = require('mongoose');
// 创建视频模型
const VideoSchema = new mongoose.Schema({
  // 视频ID字段
  videoId: {
    type: String,
    unique: true,
    required: true
  },
  // 用户ID字段
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  //视频状态
  status: {
    type: String,
    enum: ['待审核', '已发布', '已下架'],
    default: '已发布'  // 默认状态为待审核//测试配置记得修改
  },
   // 播放次数字段
  playCount: {
    type: Number,
    default: 0
  },
   // 点赞次数字段
  likeCount: {
    type: Number,
    default: 0
  },
  // 评论次数字段
  commentCount: {
    type: Number,
    default: 0
  },
  // 分享次数字段
  shareCount: {
    type: Number,
    default: 0
  },
   // 标题字段
  title: {
    type: String,
    required: true,
    trim: true
  },
  // 描述字段
  description: {
    type: String,
    trim: true
  },
   // 文件路径字段
  filePath: {
    type: String,
    required: true
  },
   // 标签字段
  tags: {
    type: [String]
  },
   // 添加视频时长字段
  views: {
    type: Number,
    default: 0
  },
  // 添加视频分类字段
  category: {
    type: String,
    required: true
  },
  // 添加视频封面字段
  cover: {
    type: String
  },
   // 添加视频创建时间字段
  createdAt: {
    type: Date,
    default: Date.now
  },
  // 添加视频更新时间字段
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Video', VideoSchema);
