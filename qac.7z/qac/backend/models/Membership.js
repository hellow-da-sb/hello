const mongoose = require('mongoose');
// 定义会员计划模型结构
const MembershipSchema = new mongoose.Schema({
  // 套餐类型（月度/季度/年度）
  packageType: {
    type: String,
    enum: ['月度', '季度', '年度'],
    required: true
  },
  // 会员开始日期
  startDate: { type: Date, required: true },
  // 会员结束日期
  endDate: { type: Date, required: true },
  // 是否自动续费
  isAutoRenew: { type: Boolean, default: false },
  // 关联用户ID（外键）
  user: { 
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
});

module.exports = mongoose.model('Membership', MembershipSchema);