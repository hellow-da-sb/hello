const mongoose = require('mongoose');
// 定义用户权限模型
const UserPermissionSchema = new mongoose.Schema({
  // 是否允许上传
  canUpload: { type: Boolean, default: false },
  // 是否允许审核
  canApprove: { type: Boolean, default: false },
  // 是否允许管理用户
  canManageUsers: { type: Boolean, default: false },
  // 关联用户ID（外键）
  user: { 
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
});

module.exports = mongoose.model('UserPermission', UserPermissionSchema);